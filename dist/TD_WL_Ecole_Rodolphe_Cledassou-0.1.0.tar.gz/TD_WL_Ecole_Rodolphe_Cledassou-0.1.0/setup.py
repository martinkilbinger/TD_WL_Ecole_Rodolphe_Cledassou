# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['td_wl_ecole_rodolphe_cledassou']

package_data = \
{'': ['*']}

install_requires = \
['TreeCorr>=4.3.3,<5.0.0',
 'astropy>=5.3.2,<6.0.0',
 'matplotlib>=3.7.2,<4.0.0',
 'numpy>=1.25.2,<2.0.0']

setup_kwargs = {
    'name': 'td-wl-ecole-rodolphe-cledassou',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
